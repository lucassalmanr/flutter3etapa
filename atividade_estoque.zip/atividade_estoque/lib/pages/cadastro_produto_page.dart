import 'package:flutter/material.dart';

import '../main.dart';
import '../models/produto.dart';

class CadastroProdutoPage extends StatefulWidget {
  const CadastroProdutoPage({super.key});

  @override
  State<CadastroProdutoPage> createState() => _CadastroProdutoPageState();
}

class _CadastroProdutoPageState extends State<CadastroProdutoPage> {
  final _nome = TextEditingController();
  final _categoria = TextEditingController();
  final _quantidade = TextEditingController();
  final _preco = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    _nome.dispose();
    _categoria.dispose();
    _quantidade.dispose();
    _preco.dispose();
    super.dispose();
  }

  Future<void> _cadastrar() async {
    final quantidade = int.tryParse(_quantidade.text);
    final preco = double.tryParse(_preco.text.replaceAll(',', '.'));
    if (_nome.text.trim().isEmpty ||
        _categoria.text.trim().isEmpty ||
        quantidade == null ||
        quantidade < 0 ||
        preco == null ||
        preco < 0) {
      _show(
        'Informe dados válidos (quantidade e preço não podem ser negativos).',
      );
      return;
    }

    setState(() => _loading = true);
    await produtoProvider.cadastrar(
      Produto(
        nome: _nome.text.trim(),
        categoria: _categoria.text.trim(),
        quantidade: quantidade,
        preco: preco,
      ),
    );
    await produtoProvider.mostrarProdutosNoTerminal();
    if (!mounted) return;

    setState(() => _loading = false);
    _show('Produto cadastrado com sucesso.');
    _nome.clear();
    _categoria.clear();
    _quantidade.clear();
    _preco.clear();
  }

  void _show(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('CADASTRAR PRODUTO')),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: ListView(
          padding: const EdgeInsets.all(24),
          shrinkWrap: true,
          children: [
            TextField(
              controller: _nome,
              decoration: const InputDecoration(labelText: 'Nome'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _categoria,
              decoration: const InputDecoration(labelText: 'Categoria'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _quantidade,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Quantidade'),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _preco,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(labelText: 'Preço'),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _loading ? null : _cadastrar,
              child: Text(_loading ? 'CADASTRANDO...' : 'CADASTRAR PRODUTO'),
            ),
          ],
        ),
      ),
    ),
  );
}
