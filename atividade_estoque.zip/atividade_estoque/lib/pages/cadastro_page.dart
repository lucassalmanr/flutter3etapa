import 'package:flutter/material.dart';

import '../main.dart';
import '../models/usuario.dart';

class CadastroPage extends StatefulWidget {
  const CadastroPage({super.key});
  @override
  State<CadastroPage> createState() => _CadastroPageState();
}

class _CadastroPageState extends State<CadastroPage> {
  final _nome = TextEditingController();
  final _email = TextEditingController();
  final _senha = TextEditingController();
  bool _loading = false;
  @override
  void dispose() {
    _nome.dispose();
    _email.dispose();
    _senha.dispose();
    super.dispose();
  }

  Future<void> _cadastrar() async {
    if ([_nome.text, _email.text, _senha.text].any((v) => v.trim().isEmpty)) {
      _show('Preencha todos os campos.');
      return;
    }
    setState(() => _loading = true);
    final criado = await usuarioProvider.cadastrar(
      Usuario(
        nome: _nome.text.trim(),
        email: _email.text.trim(),
        senha: _senha.text,
      ),
    );
    if (!mounted) return;
    setState(() => _loading = false);
    if (!criado) {
      _show('E-mail já cadastrado.');
      return;
    }
    _show('Conta criada com sucesso.');
    Navigator.pop(context);
  }

  void _show(String texto) =>
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(texto)));
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('CRIAR CONTA')),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _nome,
                decoration: const InputDecoration(labelText: 'Nome'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'E-mail'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _senha,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Senha'),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _loading ? null : _cadastrar,
                child: Text(_loading ? 'CADASTRANDO...' : 'CADASTRAR'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
